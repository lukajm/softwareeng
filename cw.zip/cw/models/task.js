const mongoose = require('mongoose')
const Event = require('./event')

const taskSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },

    description: {
        type: String,
    },

    date : {
        type: Date,
        required: true
    }
})

taskSchema.pre('remove', function(next) {
    Event.find({task: this.id}, (err, events) => {
        if (err) {
            next(err)
        }

        else if (events.length > 0) {
            next(new Error('This task still has events'))
        }

        else {
            next()
        }
    })
})

module.exports = mongoose.model('Task', taskSchema)