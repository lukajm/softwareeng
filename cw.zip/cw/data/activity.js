const mongoose = require('mongoose')
const Event = require('./event')

//The type of data within an Activity object
const  activityData = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    Startdate: {
        type:Date,
        required: true   
    },
        
    Taskdeadline: {
       type:Date,
        required: true  
    }
})

activityData.pre('remove', function(next) {
    Event.find({activity: this.id}, (error, events) => {
        if (error) {
            next(error)
        }

        else if (events.length > 0) {
            next(new Error('This activity has events associated with it'))
        }

        else {
            next()
        }
    })
})

module.exports = mongoose.model('Activity', activityData)