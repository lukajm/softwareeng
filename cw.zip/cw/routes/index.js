const express = require('express')
const router = express.Router()
const { ensureAuthenticated } = require('../config/authenticate');
const Task = require('../models/task')

router.get('/', (request, response) => {
    response.render('index')
})
router.get('/dashboard', ensureAuthenticated, async (request, response) => {
    let query = Task.find()
    const tasks = await query.exec({})
    response.render('dashboard', {
        tasks, tasks
    })
})


module.exports = router