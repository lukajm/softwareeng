const express = require('express');
const router = express.Router();
const bcrypt= require('bcryptjs');
const passport= require('passport');
//User object
const UserObject = require('../data/userdata');
//Login
router.get('/login', (req, res) => res.render('login'));
//Registration
router.get('/register', (req, res) => res.render('register'));


//Registration Handler
router.post('/register', (req,res) => {
    
    const { username, email, password,password2 } = req.body
    let errors = [];
    string= password
    //Ensures all fields are filled 
    if(!username || !email || !password || !password2) {
        errors.push({ msg: 'Ensure all fields are filled in.'  });
    }

    //Passwords matching?
    if(password !== password2){
        errors.push({msg: 'Please make sure that your passwords are matching.'});
    }

   

    if(password.length < 10){
        errors.push({ msg: 'Minimum password length is 10 characters to ensure account security.' });
    }

    if(errors.length > 0){
        res.render('register', {
        errors,
        username,
        email,
        password,
        password2 
    
        }); 
    } else {
        //User Valid
        UserObject.findOne({email: email })
            .then(user => {
                if(user){
              //User exists
               errors.push({msg: 'User Email is registered' });
               res.render('register', {
                 errors,
                 username,
                 email,
                 password,
                 password2 
                });  
            } else {
              const newUser = new UserObject({
                username,
                email,
                password
            });

           // Hash Password
                bcrypt.genSalt(10, (err, salt) => 
                    bcrypt.hash(newUser.password,salt, (err,hash) =>{
                        if(err) throw err;
                        // Hashed the password for data protection
                        newUser.password = hash;
                        //Save User
                        newUser.save()
                         .then(user => {
                             req.flash('success_msg', 'You are now registered')
                             res.redirect('/users/login');
                         })
                         .catch(err => console.log(err));
                        console.log(newUser)
                }))
          }
        });
    }
});

// Login Handler
router.post('/login', (req,res,next)=> {
    passport.authenticate('local', {
      successRedirect: '/dashboard',
      failureRedirect: '/users/login',
      failureFlash: true   
    })(req, res, next);
});

//Logout functionality
router.get('/logout', (req,res)=>{
    req.logout();
    req.flash('success_msg', 'You have logged out of the Study planner');
    res.redirect('/users/login');
});
module.exports= router;