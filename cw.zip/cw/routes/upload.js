



const semester = require('semester.json')
console.log(semester.modules);