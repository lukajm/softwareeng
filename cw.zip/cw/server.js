//checks if we're running in our process environment or not
if (process.env.NODE_ENV !== 'production') {
    require('dotenv').config()
}

//required libraries
const express = require('express')
const app = express()
const layouts = require('express-ejs-layouts')
const parser = require('body-parser')
const flash = require('connect-flash');
const session = require('express-session');
const passport = require('passport');
const methodOverride = require('method-override')

//Passport login configuration
require('./config/passport')(passport);

//setting our view layout and directory
app.set('view engine', 'ejs')
app.set('views', __dirname + '/views')
app.use(express.urlencoded({extended:false})) //new

//setting up layout files for pages EJS
app.set('layout', 'pages/layouts')
app.use(layouts)
app.use(express.static('public')) //public views fall under this folder

//Bodyparser
app.use(parser.urlencoded({limit: '10mb', extended: false}))
app.use(methodOverride('_method'))


//Express Session (middleware)
app.use(session({
    secret: 'Wedge',
    resave: true,
    saveUninitialized: true
}));
// Passport middleware
app.use(passport.initialize());
app.use(passport.session());
// Connect flash
app.use(flash());

//Global Variable
app.use((req,res, next)=>{
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    next();
});

//setting up routes to our index
const index = require('./routes/index')
app.use('/', index)

//User route
const users = require('./routes/users')
app.use('/users', users)

//Task route
const tasks = require('./routes/tasks')
app.use('/tasks', tasks)

//Event route
const events = require('./routes/events')
app.use('/events', events)

//setting up our database (mongodb)
const mongoose = require('mongoose')
const res = require('express/lib/response')
mongoose.connect(process.env.URL, {useNewUrlParser: true})
const db = mongoose.connection
db.on('error', error => console.error(error)) //messages so we know if we have connected
db.once('open', () => console.log('successfully connected to mongoose'))

const PORT = process.env.PORT || 3000; //starts on env port or 3000 if env not found

app.listen(PORT, () => console.log(`Server started using port ${PORT}`)) //the port we are going to use

app.get('/login', (req, res)=> {
    res.render('login.ejs') //new
})
app.get('/register', (req, res)=> {
    res.render('register.ejs') //new
})

const multer = require("multer");
//for unique id's for same name files
const uuid = require('uuid').v4;
const path = require('path');
const Text = require('./models/text')

//defines the destination for the uploaded file and
//how it will be named.
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads')
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        const id = uuid();
        const filePath = `studentFiles/${id}${ext}`;
        Text.create({ filePath: filePath })
            .then(() => {
                cb(null, filePath)
            });
    }
})

const upload = multer({storage});
const fs = require('fs');

const { DESTRUCTION } = require('dns')
const bodyParser = require('body-parser')
//const app = express();

app.get('/upload', (request, response) => 
{
    response.render("upload")
});

app.get('/gantt', (request, response) =>
{
    response.render("gantt")
});

app.use(express.static(__dirname + '/public'));

app.get('/calendar', (request, response) =>
{
    response.render("calendar")
});


const Module = require('./module');
const formidable = require("formidable");

app.use(bodyParser.json())

app.post('/upload',  upload.single('doc'), async (req,res) =>
{
    
    console.log(req.body)
    const module = new Module({
        name: req.body.name
    })
    const newModule = await module.save()
    console.log(newModule.name)
    console.log(req.body)
});

app.get('/studentFiles', (req, res) => {
    Text.find()
        .then((images) => {
            return res.json({ status: 'OK', images});
        })
});


app.listen(3003, () => console.log('App is listening...'))


var jsonParser = bodyParser.json();

app.post('/dashboard', jsonParser,  function(req, res)
{
    console.log(req.body)
    res.render('dashboard')

})


app.get('/uploads/studentFiles', (req,res) =>
{

    res.header("Content-Type", 'application.json')
    console.log(res)
})