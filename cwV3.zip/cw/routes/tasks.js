const express = require('express')
const Task = require('../models/task')
const Event = require('../models/event')
const router = express.Router()

// All Tasks Router
router.get('/', async (req, res) => {

    let searchOptions = {}
    if (req.query.name != null && req.query.name !== '') {
        searchOptions.name = new RegExp(req.query.name, 'i')
    }

    try {
        const tasks = await Task.find(searchOptions)
        res.render('tasks/index', {tasks: tasks, searchOptions: req.query})
    }

    catch {
        res.redirect('/dashboard')
    }
})

// New Task Router
router.get('/new', (req, res) => {
    res.render('tasks/new', { task: new Task() })
})

// Create Task Router
router.post('/', async (req, res) => {
    const task = new Task({
        name: req.body.name
    })

    try {
        const newTask = await task.save()
        res.redirect(`tasks/${newTask.id}`)
    }

    catch {
        res.render('tasks/new', {
            task: task,
            errormsg: 'Error creating task'
        })
    }
})

//Show Task Router
router.get('/:id', async (req, res) => {
    try {
        const task = await Task.findById(req.params.id)
        const events = await Event.find({ task: task.id}).limit(10).exec()

        res.render('tasks/show' , {
            task: task,
            eventswithTask: events
        })
    }

    catch {
        res.redirect('/dashboard')
    }
})

//Edit Task Router
router.get('/:id/edit', async (req, res) => {

    try {
        const task = await Task.findById(req.params.id)
        res.render('tasks/edit', { task: task })
    }

    catch {
        res.redirect('/tasks')
    }
})

//Update Task Router
router.put('/:id', async (req, res) => {
    let task
    try {
        task = await Task.findById(req.params.id)
        task.name = req.body.name
        await task.save()
        res.redirect(`/tasks/${task.id}`)
    }

    catch {
        if (task == null) {
            res.redirect('/dashboard')
        }

        else {
            res.render('tasks/edit', {
                task: task,
                errormsg: 'Error updating task'
            })
        }
    }
})

//Delete Task Router
router.delete('/:id', async (req, res) => {
    let task
    try {
        task = await Task.findById(req.params.id)
        await task.remove()
        res.redirect('/tasks')
    }

    catch {
        if (task == null) {
            res.redirect('/dashboard')
        }

        else {
            res.redirect(`/tasks/${task.id}`)
        }
    }
})

module.exports = router