const express = require('express')
const Event = require('../models/event')
const Task = require('../models/task')
const router = express.Router()

// All Events Router
router.get('/', async (req, res) => {

    let query = Event.find()

    if (req.query.title != null && req.query.title != '') {
        query = query.regex('title', new RegExp(req.query.title, 'i'))
    }

    if (req.query.date != null && req.query.date != '') {
        query = query.lte('date', req.query.date)
    }


    try {
        const events = await query.exec({})
        res.render('events/index', {
            events: events,
            searchOptions: req.query
        })
    }

    catch {
        res.redirect('/')
    }
})

// New Event Router
router.get('/new', async (req, res) => {
    renderNewEvent(res, new Event())
})

// Create Event Router
router.post('/', async (req, res) => {
    const event = new Event({
        title: req.body.title,
        task: req.body.task,
        date: new Date(req.body.date),
        description: req.body.description
    })

    try {
        const newEvent = await event.save()
        res.redirect(`events/${newEvent.id}`)
    }

    catch {
        renderNewEvent(res, event, true)
    }
})

//Show Event Route
router.get('/:id', async (req, res) => {
    try {
        const event = await Event.findById(req.params.id).populate('task').exec()
        res.render('events/show', {event: event})
    }

    catch {
        res.redirect('/')
    }
})

//Edit Event Route
router.get('/:id/edit', async (req, res) => {

    try {
        const event = await Event.findById(req.params.id)
        renderEditEvent(res, event)
    }

    catch {
        res.redirect('/dashboard')
    }
})

// Update Event Router
router.put('/:id', async (req, res) => {
    let event
    try {
        event = await Event.findById(req.params.id)
        event.title = req.body.title
        event.task = req.body.task
        event.date = new Date(req.body.date)
        event.description = req.body.description

        await event.save()
        res.redirect(`/events/${event.id}`)
    }

    catch {
        if (event != null) {
            renderEditEvent(res, event, true)
        }
        else {
            redirect('/')
        }
    }
})

//Delete event router
router.delete('/:id', async (req, res) => {
    let event
    try {
        event = await Event.findById(req.params.id)
        await event.remove()
        res.redirect('/events')
    }

    catch {
        if (event != null) {
            res.render('events/show', {
                event: event,
                errormsg: 'Could not remove event'
            })
        }

        else {
            res.redirect('/')
        }
    }
})

//Functions to create new events and edit them
async function renderNewEvent(res, event, error = false) {
    renderForm(res, event, 'new', error)
}

async function renderEditEvent(res, event, error = false) {
    renderForm(res, event, 'edit', error)
}

async function renderForm(res, event, form, error = false) {
    try {
        const tasks = await Task.find({})
        const params = {
            tasks: tasks,
            event, event
        }

        if (error) {
            if (form == 'edit') {
                params.errormsg = 'Error Updating Event'
            }

            else {
                params.errormsg = 'Error Creating an Event'
            }
        }
        res.render(`events/${form}`, params)
    }

    catch {
        res.redirect('/events')
    }
}


module.exports = router