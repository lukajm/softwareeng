const mongoose = require('mongoose')

//The type of data within an Event object
const  eventData = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },

    notes: {
        type: String,
    },

    date: {
        type: Date,
        required: true
    },

    activity: {
        type: mongoose.Schema.Types.ObjectId,//references our activity by its id
        required: true,
        ref: 'Activity'
    }
})

module.exports = mongoose.model('Event', eventData)